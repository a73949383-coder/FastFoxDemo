FAST FOX DEMO — cloud build bundle

This bundle lets GitHub Actions build the Android APK without installing AndroidIDE.
The app is a demo only. It does not control real scooters.

Setup (GitHub account required):
1. Create a new public or private repository on GitHub.
2. Upload FastFoxDemoAndroid_project.zip to the repository root and commit it.
3. Use Add file > Create new file. In the filename box enter .github/workflows/build.yml.
4. Copy the complete contents from the build.yml file included in this bundle, then commit the file.
5. Open the repository's Actions tab, select Build Android APK, tap Run workflow (if not already running), and open the latest successful run.
6. At the bottom, under Artifacts, download FastFoxDemo-debug-apk.zip, extract it, and install app-debug.apk on the phone.

If uploading the ZIP first triggers a failed workflow because build.yml does not exist yet, that is expected; add the workflow file and run it again.
